﻿using System;

namespace Variables.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 3;
            string name = "Alex";
            char character = 'c';
            Console.WriteLine("Hello World!");
        }
    }
}
