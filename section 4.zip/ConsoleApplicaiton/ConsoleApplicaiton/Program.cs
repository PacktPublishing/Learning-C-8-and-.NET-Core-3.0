﻿using System;
using System.IO;

namespace ConsoleApplicaiton
{
    public enum Types
    {
        integer, text,decimalkey
    }
    
    class Program
    {
        private static void Print()
        {
            Console.WriteLine("Writing some values");
            Console.WriteLine("Writing some values again");
            Console.WriteLine("Writing some values once more");
        }
        private static void PrintWithName(string name)
        {
            Console.WriteLine($"This is the name:{name}");
        }
        private static string GetFullName(string firstName, string lastName)
        {
            return $"{firstName} {lastName}";
        }
        static int i = 0;
        private static void WriteNumber()
        {
            Console.WriteLine(1);
            i++;

            if (i<20)
            {
                WriteNumber(); 
            }
        }

        private static void WriteLineToFile(string line)
        {
            StreamWriter writer = new StreamWriter("C://Files//test.txt");
            writer.WriteLine(line);
            writer.Close();
            writer.Dispose();
        }

        private static string ReadLineFromFile()
        {
            StreamReader reader = new StreamReader("C://Files//test.txt");
            string line = reader.ReadLine();
            reader.Close();
            reader.Dispose();
            return line;
        }
        static void Main(string[] args)
        {
            Print();
            PrintWithName("Mark");
            Console.WriteLine(GetFullName("Alex", "Steven"));
            WriteNumber();
            WriteLineToFile("This is the first line");
            ReadLineFromFile();

            try
            {
                int x, y, z;
                x = 5;
                y = 0;
                z = x / y;
            }
            catch (DivideByZeroException e)
            {

                Console.WriteLine($"An Exception occured : {e.Message}");
            }
            Console.Read();
        }
    }
}
