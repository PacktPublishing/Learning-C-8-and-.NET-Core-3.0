﻿using System;

namespace ConsoleApplicaiton
{
    public enum Types
    {
        integer, text,decimalkey
    }
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10;
            int y = 20;
            if (x > y && y == 20)
            {
                x += y;
            }
            else
            {
                y += x;
            }
            Console.WriteLine($"x={x} \n {y}");

            x = 4;
            switch (x)
            {
                case 4:
                    Console.WriteLine("true");
                    break;
                case 5:
                    Console.WriteLine("false");
                    break;
                default:
                    break;
            }
            Types types = Types.integer;
            switch (types)
            {
                case Types.integer:
                    break;
                case Types.text:
                    break;
                case Types.decimalkey:
                    break;
                default:
                    Console.WriteLine("false");
                    break;
            }
            int[] xarray = new int[10];
            xarray[0] = 5;
            int[][] d2array = new int[10][];
            d2array[0] = new int[10];
            d2array[0][0] = 10;
            Console.WriteLine($"Single dimention first element is {xarray[0]} \nAnd the two dimnetional array first element is {d2array[0][0]}");
            for (int increment = 0; increment < 10; increment++)
            {
                Console.WriteLine(increment);
            }
            var array = new int[10] { 1, 2, 3, 4, 5, 6, 7, 8, 9,0 };
            foreach (var item in array)
            {
                Console.WriteLine(item);
            }

            int i = 0;
            while (i < 5)
            {
                i++;
                Console.WriteLine(i);
            }
            i = 5;
            do
            {
                i++;
                Console.WriteLine($"\ndowhile is {i}");
            } while (i < 5);

            Console.Read();
        }
    }
}
