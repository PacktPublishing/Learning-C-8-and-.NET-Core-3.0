﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp
{
    class Manager:Employee
    {
        public override string GetTitle()
        {
            return "Manager";
        }
    }
}
