﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp
{
    class Employee
    {
        public virtual string GetTitle()
        {
            return "Employee";
        }
    }
}
