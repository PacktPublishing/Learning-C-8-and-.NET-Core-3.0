﻿using System;

namespace ConsoleApp
{
    class Program
    {
        public static void DoSomething() {
        }
        public static void DoSomething(int i) {
        }
        static void Main(string[] args)
        {
            DoSomething();
            DoSomething(8);
            Manager manager = new Manager();
            Console.WriteLine(manager.GetTitle());
            Console.Read();
        }
    }
}
